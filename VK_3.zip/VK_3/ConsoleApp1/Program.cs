﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime;

using System.Diagnostics;

class Program
{
    static void get_processes()
    {
        Process[] processes = Process.GetProcesses();

        Console.WriteLine("Список запущенных процессов:");

        foreach (Process process in processes)
        {
            Console.WriteLine($"ID: {process.Id} - Имя: {process.ProcessName}");
        }
    }

    static void del_processes()
    {
        Console.Write("Введите ID процесса для завершения: ");
        int processId;
        try
        {
            processId = Convert.ToInt32(Console.ReadLine());

            Process process = Process.GetProcessById(processId);
            if (process != null)
            {
                process.Kill();
                Console.WriteLine($"Процесс с ID {processId} успешно завершен.");
            }
            else
            {
                Console.WriteLine($"Процесс с ID {processId} не найден.");
            }
        }
        catch (FormatException)
        {
            Console.WriteLine("Некорректный ввод ID процесса. Введите целое число.");
        }
        catch (OverflowException)
        {
            Console.WriteLine("Введенное число слишком большое или слишком маленькое.");
        }
        catch (ArgumentException)
        {
            Console.WriteLine("Процесс с указанным ID не существует.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }
    }

    static void Main()
    {
        get_processes();

        do
        {
            del_processes();
        } while (true);
        
    }
}
        
